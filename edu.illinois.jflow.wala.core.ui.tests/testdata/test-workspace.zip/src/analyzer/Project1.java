package analyzer;

public class Project1 {
	public static void main(String[] args) {
		int a = 2;
		int b = a + 2;
	}
}
