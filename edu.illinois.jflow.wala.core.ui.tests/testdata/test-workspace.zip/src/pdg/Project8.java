package pdg;

public class Project8 {
	int field1;

	void method(int param) {
		int a = producer(param);
		int b = producer(field1);
		int c = producer(b);
	}

	int producer(int input) {
		return input + 2;
	}
}
