package partitionchecker;

public class Project12 {
	public static void main(String[] args) {
		for (int i = 0; i < 100; i++) {
			// Begin Stage1
			Y y = new Y();
			X x = new X(y);
			// End Stage1

			// Begin Stage2
			x.modify(); // Indirectly modifies y that is not being transferred
			// End Stage2
		}
	}
}

class X {
	Y y;

	X(Y y) {
		this.y = y;
	}

	void modify() {
		y.field = 2;
	}
}

class Y {
	int field;
}