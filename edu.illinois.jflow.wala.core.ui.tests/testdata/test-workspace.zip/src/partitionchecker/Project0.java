package partitionchecker;

public class Project0 {
	Integer field;

	public static void main(String[] args) {
		Project0 p1 = new Project0();
		Project0 p2 = new Project0();
		Integer local1 = p1.field;
		Integer local2 = p2.field;
	}
}
