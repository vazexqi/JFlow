package partitionchecker;

public class Project0a {
	Object field;

	public static void main(String[] args) {
		Project0a p1 = new Project0a();
		Project0a p2 = new Project0a();
		Object local1 = p1.field;
		Object local2 = p2.field;
	}
}
