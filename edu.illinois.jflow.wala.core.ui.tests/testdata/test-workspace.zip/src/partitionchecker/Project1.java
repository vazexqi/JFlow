package partitionchecker;

public class Project1 {
// TODO: Insert basic test here with no heap data dependencies
}
